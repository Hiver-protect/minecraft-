==============================================================================
                 MINESTARS - PACK DE TEXTURES OFFICIEL
==============================================================================

Ce dossier contient l'architecture complète et prête à l'emploi du Resource Pack
pour toutes vos Armes, Armures, Outils, Boucliers, Reliques et Monstres !

------------------------------------------------------------------------------
1. TABLEAU DES IDENTIFIANTS CUSTOM MODEL DATA (CMD)
------------------------------------------------------------------------------

[ARMES MYTHIQUES]
• 10001 : Lame Stellaire (Épée en Netherite)
• 10002 : Hache Tellurique (Hache en Netherite)
• 10003 : Faux de la Faucheuse (Houe en Netherite)
• 10004 : Marteau de Thor (Hache en Netherite)
• 10005 : Katana du Vent (Épée en Diamant)
• 10006 : Lame Glaciaire (Épée en Diamant)
• 10007 : Épée Vampirique (Épée en Netherite)
• 10008 : Hache Infernale (Hache en Netherite)
• 10009 : Lame du Dragon (Épée en Netherite)
• 10010 : Lame du Sculk / Warden (Épée en Netherite)
• 10011 : Dague Toxique (Épée en Diamant)
• 10012 : Épée du Chaos (Épée en Netherite)
• 10013 : Lame de l'Infini (Épée en Netherite)
• 10014 : Arc du Phénix (Arc)
• 10015 : Arc de Gravité (Arc)
• 10016 : Arc du Dragon (Arc)
• 10017 : Arbalète Explosive (Arbalète)
• 10018 : Trident des Abysses (Trident)
• 10019 : Bâton de Tempête (Bâton de Blaze)
• 10020 : Dague de l'Ombre (Épée en Diamant)

[OUTILS & BOUCLIERS]
• 20001 : Pioche du Titan 3x3 (Pioche en Netherite)
• 20002 : Pioche Auto-Smelt (Pioche en Netherite)
• 20003 : Hache Sylvestre (Hache en Netherite)
• 20004 : Pelle du Colosse 3x3 (Pelle en Netherite)
• 20005 : Canne des Profondeurs (Canne à Pêche)
• 20006 : Bouclier de l'Aegis (Bouclier)

[RELIQUES & ARTEFACTS]
• 30001 : Cœur du Titan (Étoile du Nether)
• 30002 : Amulette des Vents (Plume)
• 30003 : Anneau des Enfers (Crème de Magma)
• 30004 : Totem Ancestral (Totem d'Immortalité)
• 30005 : Ailes Célestes (Élytres)
• 30006 : Ailes du Phénix (Élytres)
• 30007 : Orbe de Vitalité (Cœur de la Mer)
• 30008 : Gemme Sanglante (Teinture Rouge)

[FOURNITURES & MEUBLES 3D]
• 40001 : Chaise en Chêne Artisanale 3D (Carved Pumpkin / Paper)
• 40002 : Table Moderne en Chêne Noir 3D (Carved Pumpkin / Paper)
• 40003 : Canapé Confort Velours 3D (Carved Pumpkin / Paper)
• 40004 : Lampadaire sur Pied 3D (Carved Pumpkin / Paper)

[VÊTEMENTS & COSMÉTIQUES 3D]
• 50001 : Chapeau d'Archimage 3D (Carved Pumpkin / Leather Helmet)
• 50002 : Couronne Royale Impériale 3D (Carved Pumpkin / Leather Helmet)
• 50003 : Casque de Chevalier Croisé 3D (Carved Pumpkin / Leather Helmet)
• 50004 : Sac à dos d'Aventurier 3D (Carved Pumpkin / Leather Helmet)

[POSTES D'ARTISANAT & BLOCS 3D ACTIFS]
• Table de Crafting 3D (Scie, marteau en relief, rebords biseautés)
• Table de Forge 3D (Lingots, pinces et marteau en relief)
• Table de Cartographie 3D (Rouleaux de cartes et parchemins)
• Bibliothèque 3D (Livres en relief à profondeurs variées)

------------------------------------------------------------------------------
2. COMMENT AJOUTER DES TEXTURES OU MODÈLES 3D (.png / .json)
------------------------------------------------------------------------------
1. Placez vos images PNG dans le dossier :
   assets/minecraft/textures/item/custom/
   (Exemple : lame_stellaire.png, marteau_thor.png, bouclier_aegis.png)

2. Si vous utilisez des modèles 3D Blockbench (fichiers .json) :
   Placez-les dans :
   assets/minecraft/models/item/custom/

------------------------------------------------------------------------------
3. PACKS DE MONSTRES RECOMMANDÉS (À COMBINER OU GLISSER DEDANS)
------------------------------------------------------------------------------
• Fresh Animations : Téléchargez le pack sur CurseForge et extrayez le dossier
  assets/minecraft/optifine ou assets/minecraft/cem directement dans votre pack !
• Spookier Mobs / Stay True : Vous pouvez fusionner leurs dossiers assets.

------------------------------------------------------------------------------
4. INSTALLATION SUR VOTRE SERVEUR MINECRAFT
------------------------------------------------------------------------------
1. Sélectionnez tout le contenu de ce dossier "resourcepack" et compressez-le en ".zip".
2. Téléversez votre fichier ZIP sur https://mc-packs.net/ (gratuit et instantané).
3. Copiez le lien généré et collez-le dans "server.properties" :
   resource-pack=https://...
   require-resource-pack=true
==============================================================================
